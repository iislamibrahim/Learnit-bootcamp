function updatePrintSettings() {
  const orientation = document.getElementById("orientation").value;
  const paperSize = document.getElementById("paperSize").value;
  const colorMode = document.getElementById("colorMode").value;

  let printStyle = document.createElement("style");
  printStyle.innerHTML = `
      @media print {
        @page {
          size: ${paperSize} ${orientation};
        }
        body {
          color: ${colorMode === "mono" ? "black" : "initial"};
        }
      }
    `;
  document.head.appendChild(printStyle);

  window.print();
}
