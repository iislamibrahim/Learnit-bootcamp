const canvas = document.getElementById("circleCanvas");
const ctx = canvas.getContext("2d");
const colorPicker = document.getElementById("colorPicker");
const generateBtn = document.getElementById("generateBtn");

function drawRandomCircles() {
  const color = colorPicker.value;
  const numberOfCircles = Math.floor(Math.random() * 100) + 50;
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  for (let i = 0; i < numberOfCircles; i++) {
    const x = Math.random() * canvas.width;
    const y = Math.random() * canvas.height;
    const radius = Math.random() * 30 + 10;

    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.strokeStyle = color;
    ctx.stroke();
  }
}

generateBtn.addEventListener("click", drawRandomCircles);
