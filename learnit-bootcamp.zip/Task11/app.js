const users = [
    { username: 'user1', password: 'pass1' },
    { username: 'user2', password: 'pass2' }
];

const questions = {
    chemistry: {
        easy: ['What is H2O?', 'What is the atomic number of hydrogen?'],
        medium: ['What is the pH of pure water?', 'Who discovered the electron?'],
        hard: ['What is the Schrödinger equation?', 'What is the molecular geometry of water?']
    },
    physics: {
        easy: ['What is Newton\'s first law?', 'What is the speed of light?'],
        medium: ['What is Planck\'s constant?', 'Explain the theory of relativity.'],
        hard: ['What is quantum entanglement?', 'What is the Heisenberg uncertainty principle?']
    }
};

let currentSubject = '';
let currentLevel = '';
let currentUser = '';

document.getElementById('loginBtn').addEventListener('click', login);
document.getElementById('nextQuestion').addEventListener('click', getRandomQuestion);
document.getElementById('endApp').addEventListener('click', endApp);

function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    const authenticated = users.some(user => user.username === username && user.password === password);
    
    if (authenticated) {
        currentUser = username;
        document.getElementById('loginPage').style.display = 'none';
        document.getElementById('quizPage').style.display = 'block';
        selectTopic();
    } else {
        document.getElementById('errorMessage').innerText = 'Invalid username or password';
    }
}

function selectTopic() {
    currentSubject = prompt("Choose a topic: chemistry or physics").toLowerCase();
    currentLevel = prompt("Choose a level: easy, medium, or hard").toLowerCase();

    if (!questions[currentSubject] || !questions[currentSubject][currentLevel]) {
        alert("Invalid selection! Try again.");
        selectTopic();
    } else {
        document.getElementById('quizTitle').innerText = `${currentSubject.toUpperCase()} - ${currentLevel.toUpperCase()} Level`;
        getRandomQuestion();
    }
}

function getRandomQuestion() {
    const questionList = questions[currentSubject][currentLevel];
    const randomQuestion = questionList[Math.floor(Math.random() * questionList.length)];
    document.getElementById('questionBox').innerText = randomQuestion;
}

function endApp() {
    document.getElementById('loginPage').style.display = 'block';
    document.getElementById('quizPage').style.display = 'none';
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
    document.getElementById('errorMessage').innerText = '';
    document.getElementById('questionBox').innerText = '';
    currentUser = '';
}
