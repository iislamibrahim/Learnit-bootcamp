function addUsername(list) {
    list.forEach(person => {
      person.username = `${person.firstName.toLowerCase()}${person.lastName[0].toLowerCase()}${person.age}`;
    });
    return list;
  }
  
  var list1 = [
    { firstName: 'Emily', lastName: 'N.', country: 'Ireland', continent: 'Europe', age: 30, language: 'Ruby' },
    { firstName: 'Nor', lastName: 'E.', country: 'Malaysia', continent: 'Asia', age: 20, language: 'Clojure' }
  ];
  
  console.log(addUsername(list1));


  function countMeals(list) {
    return list.reduce((acc, person) => {
      acc[person.meal] = (acc[person.meal] || 0) + 1;
      return acc;
    }, {});
  }
  
  var list1 = [
    { firstName: 'Noah', lastName: 'M.', country: 'Switzerland', continent: 'Europe', age: 19, language: 'C', meal: 'vegetarian' },
    { firstName: 'Anna', lastName: 'R.', country: 'Liechtenstein', continent: 'Europe', age: 52, language: 'JavaScript', meal: 'standard' },
    { firstName: 'Ramona', lastName: 'R.', country: 'Paraguay', continent: 'Americas', age: 29, language: 'Ruby', meal: 'vegan' },
    { firstName: 'George', lastName: 'B.', country: 'England', continent: 'Europe', age: 81, language: 'C', meal: 'vegetarian' },
  ];
  
  console.log(countMeals(list1));


  function askForMissingDetails(list) {
    return list
      .filter(person => {
        for (let key in person) {
          if (person[key] === null) {

            person.question = `Hi, could you please provide your ${key}.`;
            return true; 
          }
        }
        return false; 
      });
  }
  
  var list1 = [
    { firstName: null, lastName: 'I.', country: 'Argentina', continent: 'Americas', age: 35, language: 'Java' },
    { firstName: 'Lukas', lastName: 'X.', country: 'Croatia', continent: 'Europe', age: 35, language: null },
    { firstName: 'Madison', lastName: 'U.', country: 'United States', continent: 'Americas', age: 32, language: 'Ruby' }
  ];
  
  console.log(askForMissingDetails(list1));


  function findSenior(list) {
    const maxAge = Math.max(...list.map(person => person.age));
    return list.filter(person => person.age === maxAge);
  }
  
  var list1 = [
    { firstName: 'Gabriel', lastName: 'X.', country: 'Monaco', continent: 'Europe', age: 49, language: 'PHP' },
    { firstName: 'Odval', lastName: 'F.', country: 'Mongolia', continent: 'Asia', age: 38, language: 'Python' },
    { firstName: 'Emilija', lastName: 'S.', country: 'Lithuania', continent: 'Europe', age: 19, language: 'Python' },
    { firstName: 'Sou', lastName: 'B.', country: 'Japan', continent: 'Asia', age: 49, language: 'PHP' },
  ];
  
  console.log(findSenior(list1));


  function countLanguages(list) {
    return list.reduce((acc, person) => {
      acc[person.language] = (acc[person.language] || 0) + 1;
      return acc;
    }, {});
  }
  
  var list1 = [
    { firstName: 'Noah', lastName: 'M.', country: 'Switzerland', continent: 'Europe', age: 19, language: 'C' },
    { firstName: 'Anna', lastName: 'R.', country: 'Liechtenstein', continent: 'Europe', age: 52, language: 'JavaScript' },
    { firstName: 'Ramon', lastName: 'R.', country: 'Paraguay', continent: 'Americas', age: 29, language: 'Ruby' },
    { firstName: 'George', lastName: 'B.', country: 'England', continent: 'Europe', age: 81, language: 'C' },
  ];
  
  console.log(countLanguages(list1));