const questions = [
  { question: "What is 2 + 2?", answer: "4", difficulty: "easy" },
  {
    question: "What is the capital of France?",
    answer: "Paris",
    difficulty: "easy",
  },
  { question: "What is 10 * 10?", answer: "100", difficulty: "easy" },
  { question: "What is 5 - 3?", answer: "2", difficulty: "easy" },
  {
    question: "What is the capital of Spain?",
    answer: "Madrid",
    difficulty: "easy",
  },
  { question: "What is 15 / 3?", answer: "5", difficulty: "easy" },
  { question: "What is 9 + 6?", answer: "15", difficulty: "easy" },
  {
    question: "What is the capital of Germany?",
    answer: "Berlin",
    difficulty: "easy",
  },
  { question: "What is 8 * 7?", answer: "56", difficulty: "easy" },
  { question: "What is 12 - 8?", answer: "4", difficulty: "easy" },
  {
    question: "What is the square root of 144?",
    answer: "12",
    difficulty: "hard",
  },
  {
    question: "What is the capital of Iceland?",
    answer: "Reykjavik",
    difficulty: "hard",
  },
  { question: "What is the cube root of 27?", answer: "3", difficulty: "hard" },
  { question: "Solve 12x = 36. What is x?", answer: "3", difficulty: "hard" },
  {
    question: "What is the speed of light in m/s?",
    answer: "299792458",
    difficulty: "hard",
  },
  {
    question: "What is the capital of Australia?",
    answer: "Canberra",
    difficulty: "hard",
  },
  {
    question: "What is the derivative of x^2?",
    answer: "2x",
    difficulty: "hard",
  },
  { question: "What is 2^10?", answer: "1024", difficulty: "hard" },
  {
    question: "What is the capital of Canada?",
    answer: "Ottawa",
    difficulty: "hard",
  },
  { question: "Solve x^2 = 16. What is x?", answer: "4", difficulty: "hard" },
];

const shuffleArray = (arr) => arr.sort(() => Math.random() - 0.5);

const startTimer = (seconds, callback) => {
  let timer = seconds;
  const interval = setInterval(() => {
    timer--;
    console.log(`Time remaining: ${timer}s`);
    if (timer <= 0) {
      clearInterval(interval);
      callback(); 
    }
  }, 1000);
};

const calculateScore = (questions) => {
  return questions.reduce((total, q) => {
    if (q.correct) {
      return total + (q.difficulty === "easy" ? 1 : 3);
    }
    return total;
  }, 0);
};

const getResultMessage = (score) => {
  if (score <= 10) return "Bad";
  if (score <= 20) return "Fair";
  return "Good";
};

const askQuestion = (question, onTimeOut) => {
  return new Promise((resolve) => {
    startTimer(10, () => {
      alert("Time is over!");
      resolve(false);
      onTimeOut();
    });

    const answer = prompt(question.question);
    if (answer === question.answer) {
      resolve(true);
    } else {
      resolve(false);
    }
  });
};

const runQuiz = async () => {
  let score = 0;
  const shuffledQuestions = shuffleArray(questions); 
  for (let i = 0; i < shuffledQuestions.length; i++) {
    const question = shuffledQuestions[i];
    const correct = await askQuestion(question, () =>
      console.log("Moving to next question...")
    );

    shuffledQuestions[i].correct = correct;

    if (!correct) {
      alert(`Wrong! The correct answer was ${question.answer}`);
    }
  }

  score = calculateScore(shuffledQuestions);
  alert(`Your final score is ${score}. You are: ${getResultMessage(score)}`);
};

runQuiz();
