//Task 1 
function isLanguageBalanced(list) {
    let languageCount = {
      Python: 0,
      Ruby: 0,
      JavaScript: 0
    };
  
    list.forEach(dev => {
      if (dev.language in languageCount) {
        languageCount[dev.language]++;
      }
    });
  
    let counts = Object.values(languageCount);
    
    let maxCount = Math.max(...counts);
    let minCount = Math.min(...counts);
    
    return maxCount <= 2 * minCount;
  }
  
  var list1 = [
    { firstName: 'Daniel', lastName: 'J.', country: 'Aruba', continent: 'Americas', age: 42, language: 'Python' },
    { firstName: 'Kseniya', lastName: 'T.', country: 'Belarus', continent: 'Europe', age: 22, language: 'Ruby' },
    { firstName: 'Sou', lastName: 'B.', country: 'Japan', continent: 'Asia', age: 43, language: 'Ruby' },
    { firstName: 'Hanna', lastName: 'L.', country: 'Hungary', continent: 'Europe', age: 95, language: 'JavaScript' },
    { firstName: 'Jayden', lastName: 'P.', country: 'Jamaica', continent: 'Americas', age: 18, language: 'JavaScript' },
    { firstName: 'Joao', lastName: 'D.', country: 'Portugal', continent: 'Europe', age: 25, language: 'JavaScript' }
  ];
  
  console.log(isLanguageBalanced(list1));  

  //Task 2
  function getAverageAge(list) {
    let totalAge = list.reduce((sum, dev) => sum + dev.age, 0);
    
    let numberOfDevelopers = list.length;
    
    let averageAge = Math.round(totalAge / numberOfDevelopers);
    
    return averageAge;
  }
  
  var list1 = [
    { firstName: 'Maria', lastName: 'Y.', country: 'Cyprus', continent: 'Europe', age: 30, language: 'Java' },
    { firstName: 'Victoria', lastName: 'T.', country: 'Puerto Rico', continent: 'Americas', age: 70, language: 'Python' }
  ];
  
  console.log(getAverageAge(list1));  

  //Task 3

  function allContinents(list) {
    const requiredContinents = new Set(['Africa', 'Americas', 'Asia', 'Europe', 'Oceania']);
    
    const representedContinents = new Set(list.map(dev => dev.continent));
    
    for (let continent of requiredContinents) {
      if (!representedContinents.has(continent)) {
        return false;  
      }
    }
    
    return true; 
  }
  
  var list1 = [
    { firstName: 'Fatima', lastName: 'A.', country: 'Algeria', continent: 'Africa', age: 25, language: 'JavaScript' },
    { firstName: 'Agustín', lastName: 'M.', country: 'Chile', continent: 'Americas', age: 37, language: 'C' },
    { firstName: 'Jing', lastName: 'X.', country: 'China', continent: 'Asia', age: 39, language: 'Ruby' },
    { firstName: 'Laia', lastName: 'P.', country: 'Andorra', continent: 'Europe', age: 55, language: 'Ruby' },
    { firstName: 'Oliver', lastName: 'Q.', country: 'Australia', continent: 'Oceania', age: 65, language: 'PHP' }
  ];
  
  console.log(allContinents(list1)); 

  //Task4

  function isSameLanguage(list) {
    const firstLanguage = list[0].language;
    
    return list.every(dev => dev.language === firstLanguage);
  }
  
  var list1 = [
    { firstName: 'Daniel', lastName: 'J.', country: 'Aruba', continent: 'Americas', age: 42, language: 'JavaScript' },
    { firstName: 'Kseniya', lastName: 'T.', country: 'Belarus', continent: 'Europe', age: 22, language: 'JavaScript' },
    { firstName: 'Hanna', lastName: 'L.', country: 'Hungary', continent: 'Europe', age: 65, language: 'JavaScript' }
  ];
  
  console.log(isSameLanguage(list1));