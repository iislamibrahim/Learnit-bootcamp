const table = document.querySelector('table');
table.addEventListener('click', (event) => {
  if (event.target.tagName === 'TD') {
    const clone = event.target.cloneNode(true);
    const randomColor = '#' + Math.floor(Math.random()*16777215).toString(16);
    clone.style.backgroundColor = randomColor;
    document.body.appendChild(clone);
  }
});

