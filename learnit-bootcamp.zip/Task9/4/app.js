const form = document.getElementById("styleForm");
const textDisplay = document.getElementById("textDisplay");

form.addEventListener("change", function () {
  const formData = new FormData(form);
  const styles = {
    fontFamily: formData.get("fontFamily"),
    textAlign: formData.get("textAlign"),
    lineHeight: formData.get("lineHeight"),
    letterSpacing: formData.get("letterSpacing"),
    textIndent: formData.get("textIndent"),
    textTransform: formData.get("textTransform"),
    textDecoration: formData.get("textDecoration"),
    borderStyle: formData.get("textBorder"),
    borderColor:
      formData.get("borderColor") === "none"
        ? "transparent"
        : formData.get("borderColor"),
  };

  Object.assign(textDisplay.style, styles);
  textDisplay.style.border = `2px ${styles.borderStyle} ${styles.borderColor}`;
});
