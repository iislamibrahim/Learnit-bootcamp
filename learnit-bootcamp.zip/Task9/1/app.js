let numberOfPersons = prompt("Enter the number of persons:");
    
    if (numberOfPersons && !isNaN(numberOfPersons)) {
        alert(`You entered: ${numberOfPersons}`);
    } else {
        alert("Please enter a valid number.");
    }


    document.getElementById('startProcess').addEventListener('click', function() {
        let numberOfPersons = prompt("Enter the number of persons:");
    
        if (!numberOfPersons || isNaN(numberOfPersons) || numberOfPersons <= 0) {
            alert("Please enter a valid number.");
            return;
        }
    
        let users = [];
    
        for (let i = 1; i <= numberOfPersons; i++) {
            let userName = prompt(`Enter user${i} name (4-9 characters):`);
    
            while (!userName || userName.length < 4 || userName.length > 9) {
                alert("Name must be between 4 and 9 characters.");
                userName = prompt(`Enter user${i} name (4-9 characters):`);
            }
    
            let userAge = prompt(`Enter user${i} age (greater than 10 and less than 60):`);
    
            while (!userAge || isNaN(userAge) || userAge <= 10 || userAge >= 60) {
                alert("Age must be greater than 10 and less than 60.");
                userAge = prompt(`Enter user${i} age (greater than 10 and less than 60):`);
            }
    
            users.push({ name: userName, age: userAge });
        }
    
        users.forEach((user, index) => {
            alert(`User ${index + 1} Information:\nName: ${user.name}\nAge: ${user.age}`);
        });
    });

    