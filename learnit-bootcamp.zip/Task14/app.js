const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

const img = new Image();
img.src = "1.jpg";

img.onload = function () {
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
};

function drawText(
  text,
  x,
  y,
  size = 40,
  color = "white",
  shadowColor = "black",
  shadowBlur = 7
) {
  ctx.font = `${size}px Impact`;
  ctx.fillStyle = color;
  ctx.textAlign = "center";
  ctx.lineWidth = 2;

  ctx.shadowColor = shadowColor;
  ctx.shadowBlur = shadowBlur;
  ctx.shadowOffsetX = 3;
  ctx.shadowOffsetY = 3;

  ctx.fillText(text.toUpperCase(), x, y);

  ctx.shadowBlur = 0;
}

function generateMeme() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

  const topText = document.getElementById("topText").value;
  const bottomText = document.getElementById("bottomText").value;

  drawText(topText, canvas.width / 2, 60);

  drawText(bottomText, canvas.width / 2, canvas.height - 40);
}
